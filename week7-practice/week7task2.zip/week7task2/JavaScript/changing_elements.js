
function myEvent1(){
    document.getElementById('text1').style.color = "red";
}

function myEvent2(){
    document.getElementById('text2').style.color = "red";
}

function myEvent3(){
    document.getElementsByName('text3').style.color = "red";
}
