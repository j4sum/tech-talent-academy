
function analyseForm(){
    window.alert("Hello " + document.getElementById('fname').value + " " + document.getElementById('lname').value + ". Your email " + document.getElementById('email').value + " has been added to the mailing list.");
}